/**
 * A class for a heap sorting algorithm
 * @author David Lybeck
 * @version 1.0
 */

import java.util.Scanner;
import java.util.Arrays;

public class HeapSorter extends Sorter{
    public static void main(String[] args){
        Integer size = null;
        boolean run = true;
        while(run) {
            try {
                size = Integer.parseInt(getInput());
                run = false;
            }
            catch (NumberFormatException Ex) {

            }
        }

        Sorter mySorter = new HeapSorter();


        int time = mySorter.timeSort(size);
        System.out.println("The array of size " + size + " took " + time + " ms to sort.");
    }


    private static String getInput(){
        Scanner scan = new Scanner(System.in);
        System.out.print("Please enter the array size:");
        String userInput = scan.nextLine();
        return userInput;
    }


    /**
     * Sorts the array using heap sort
     *
     * @param array  the array to sort
     * @param <E>
     */
    @Override
    public <E extends Comparable<E>> void sort(E[] array){
        int size = array.length - 1;
        int check = size;


        //HEAPIFY
        //runs through all the comparisons logbase2(size) times. Or all the comparisons repeating the number of times that there are rows
        for(int i = 0; i < (size - 1) * ((int) (Math.log(size) / Math.log(2)) + 1); i++){
            //Check to see if starting on right(even) or left(odd)
            if (check % 2 == 0){
                sinkRightFromChild(check, array);
            }
            else{
                sinkLeftFromChild(check, array);
            }

            //to check the spot before it
            check--;
            if(check == 0){
                //reset to end to go again
                check = size;
            }
        }

        sinkArray(check, array);

        //"Shrinks" the size of the array as it sets numbers to the end
        for(check = size; check > 0; check--) {
            //Swap biggest to the end
            E temp = array[0];
            array[0] = array[check];
            array[check] = temp;

            int parent = 0;
            boolean run = true;
            while(run) {
                //if there are 2 valid children
                if ((parent * 2 + 1) < check && (parent * 2 + 2) < check) {
                    //find the higher one and swap with it
                    if (array[parent * 2 + 1].compareTo(array[parent * 2 + 2]) < 0) {
                        //swap right if right is higher or equal
                        sinkRightFromParent(parent, array);
                        parent = parent * 2 + 2;
                    }
                    //swap left if left is higher
                    else {
                        sinkLeftFromParent(parent, array);
                        parent = parent * 2 + 1;
                    }
                }

                //if there's 1 valid child swap left (cannot be valid right and non-valid left)
                else if((parent * 2 + 1) < check){
                    sinkLeftFromParent(parent, array);
                    parent = parent * 2 + 1;
                }
                //if there's no valid children end loop
                else{
                    run = false;
                }
            }
        }
    }

    private <E extends Comparable<E>> void sinkArray(int check, E[] array) {
        //HEAPIFY
        //runs through all the comparisons logbase2(size) times. Or all the comparisons repeating the number of times that there are rows

        int checkOriginal = check;
        for(int i = 0; i < (check - 1) * ((int) (Math.log(checkOriginal) / Math.log(2)) + 1); i++){
            //Check to see if starting on right(even) or left(odd)
            if (check % 2 == 0){
                sinkRightFromChild(check, array);
            }
            else{
                sinkLeftFromChild(check, array);
            }

            //to check the spot before it
            check--;
            if(check == 0){
                //reset to end to go again
                check = checkOriginal;
            }
        }
    }

    private <E extends Comparable<E>> void sinkRightFromChild(int num, E[] array){
        //right
        if(/*parent*/array[(num-2)/2].compareTo(array[num])/*child*/ < 0){
            E temp = array[(num-2)/2];
            array[(num-2)/2] = array[num];
            array[num] = temp;
        }
    }

    private <E extends Comparable<E>> void sinkLeftFromChild(int num, E[] array){
        //left
        if(/*parent*/array[(num-1)/2].compareTo(array[num])/*child*/ < 0){
            E temp = array[(num-1)/2];
            array[(num-1)/2] = array[num];
            array[num] = temp;
        }
    }

    private <E extends Comparable<E>> void sinkRightFromParent(int parent, E[] array) {
        if(/*child*/array[parent*2 + 2].compareTo(array[parent])/*parent*/ > 0){
            E temp = array[parent * 2 + 2];
            array[parent * 2 + 2] = array[parent];
            array[parent] = temp;
        }
    }

    private <E extends Comparable<E>> void sinkLeftFromParent(int parent, E[] array){
        if(/*child*/array[parent*2 + 1].compareTo(array[parent])/*parent*/ > 0){
            E temp = array[parent * 2 + 1];
            array[parent * 2 + 1] = array[parent];
            array[parent] = temp;
        }
    }
}