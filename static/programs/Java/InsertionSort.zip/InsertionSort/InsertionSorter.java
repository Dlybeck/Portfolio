import java.util.Scanner;
import java.util.Arrays;
/**
 * A class for a insertion sorting algorithm
 *
 * @author Quinn Stober, Oliver Bacon, David Lybeck
 * @version 3/1/2022
 */
public class InsertionSorter extends Sorter
{
    /**
     * Constructor for objects of class InsertionSorter
     */
    public InsertionSorter()
    {
    }

    /**
     * Sorts the array using insertion sort
     *
     * @param array  the array to sort
     * @param <E>
     * 
     */
     public <E extends Comparable<E>>void sort(E[] array)
    {
        
        for(int i=1; i<array.length; i++){
            int j=i-1;
            while(j>=0 && array[j].compareTo(array[i])>=0){
                j--;
            }
            j++;
            E temp= array[i];
            System.arraycopy(array, j, array, j+1, i-j);
            array[j]= temp;
        }
    }
    
    public static void main(String[] args){
        int size = -1;
        while(size<=0) {
            try {
                size = Integer.parseInt(getInput());
            } catch (NumberFormatException Ex) {
                System.out.println("Invalid integer");
            }
        }

        Sorter mySorter = new InsertionSorter();
        System.out.println("Testing insertion sort.");
        int time = mySorter.timeSort(size);
        System.out.println("The array of size " + size + " took " + time + " ms to sort.");
    }

    private static String getInput(){
        Scanner scan = new Scanner(System.in);
        System.out.print("Please enter the array size:");
        String userInput = scan.nextLine();
        return userInput;
    }
}
