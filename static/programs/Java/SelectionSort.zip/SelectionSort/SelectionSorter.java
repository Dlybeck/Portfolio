/**
 * A class for a selection sorting algorithm
 * @author David Lybeck, Oliver Bacon, Quinn Stober
 * @version 1.0
 */

import java.util.Scanner;
import java.util.Arrays;

public class SelectionSorter extends Sorter{
    public static void main(String[] args){
        Integer size = null;
        boolean run = true;
        while(run) {
            try {
                size = Integer.parseInt(getInput());
                run = false;
            } catch (NumberFormatException Ex) {

            }
        }

        Sorter mySorter = new SelectionSorter();

        int time = mySorter.timeSort(size);
        System.out.println("The array of size " + size + " took " + time + " ms to sort.");
    }


    private static String getInput(){
        Scanner scan = new Scanner(System.in);
        System.out.print("Please enter the array size:");
        String userInput = scan.nextLine();
        return userInput;
    }


    /**
     * Sorts the array using selection sort
     *
     * @param array  the array to sort
     * @param <E>
     */
    @Override
    public <E extends Comparable<E>> void sort(E[] array){
        int size = array.length - 1;
        int indexMaximum = 0;
        //System.out.println(Arrays.toString(array));
        for(int i = 0; i < size; i++){
            indexMaximum = size - i;
            for(int j = 0; j < size-i; j++){
                //System.out.println("Checking index " + j);
                if(array[j].compareTo(array[indexMaximum]) > 0){
                    indexMaximum = j;
                    //System.out.println("The index maximum is now " + indexMaximum);
                }
            }
            //System.out.println(Arrays.toString(array));
            //System.out.println("Swapping " + array[indexMaximum] + " and " + array[size - i]);
            E temp = array[indexMaximum];
            array[indexMaximum] = array[size - i];
            array[size - i] = temp;
        }
        //System.out.println(Arrays.toString(array));


    }
}
