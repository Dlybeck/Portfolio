/**
*  Authors: Oliver, Quinn, David
*  This program querys the user for a string and then outputs the hash, and, or and xors of the string split into 4.
*  Verion 1.0
*/

import java.util.*;
import java.io.*;

public class BitwiseHash {
   public static void main(String[] args) {
   
      System.out.println("Give me a string, and I will calculate its hash and the bitwise and, or, and xor of its 4 bytes. Or hit enter to quit.");
      
      while(true) {
         System.out.print("> ");
         
         String userInput = queryUser();
         System.out.print("Hash: " + userInput);
         String[] binaryStringArray = getBinaryStringArray(userInput);
         int[] binaryIntArray = getBinaryIntArray(binaryStringArray);
         
         //bitwise and
         String binaryStringAnd = Integer.toBinaryString(binaryIntArray[0]&binaryIntArray[1]&binaryIntArray[2]&binaryIntArray[3]);
         System.out.print(" and: " + correctSize(binaryStringAnd, 8));
         
         //bitwise or
         String binaryStringOr = Integer.toBinaryString(binaryIntArray[0]|binaryIntArray[1]|binaryIntArray[2]|binaryIntArray[3]);
         System.out.print(" or: " + correctSize(binaryStringOr, 8));
         
         //bitwise xor
         String binaryStringXor = Integer.toBinaryString(binaryIntArray[0]^binaryIntArray[1]^binaryIntArray[2]^binaryIntArray[3]);
         System.out.print(" xor: " + correctSize(binaryStringXor, 8));
         System.out.println("");  
      }
   }
   
   private static int[] getBinaryIntArray(String[] binaryStringArray) {
      // this method convers a binary string array into a binary int array
      int[] binaryIntArray = new int[binaryStringArray.length];
      for (int i = 0; i < binaryStringArray.length; i++) {
         binaryIntArray[i] = Integer.parseInt(binaryStringArray[i], 2);
      }
      return binaryIntArray;
   } 
   
   private static String queryUser() {
      // this method makes a new scanner and will exit if the user enters nothing
      Scanner keyboardScanner = new Scanner(System.in);
      String userInput = keyboardScanner.nextLine();
      if(userInput == "") {
         System.out.println("Goodbye!");
         System.exit(1);
      }
      else {
         int userHashcode = userInput.hashCode();
         userInput = Integer.toBinaryString(userHashcode);
      }
      userInput = correctSize(userInput, 32);
      return userInput;
   }
   
   private static String correctSize(String userInput, int size) {
      //this method adds 0 to the front of a string to make sure the size of the binary string is correct
      for(int i = userInput.length(); i < size; i++) {
         userInput = "0" + userInput;
      }   
      return userInput;
   }
   
   private static String[] getBinaryStringArray(String userInput) {
      //this method splits the string into 4 8 bit strings and returns the array of strings
      String[] binaryString = new String[4];
      for(int i = 0; i < 4; i++) {
         int startIndex = i * 8;
         int endIndex = (i + 1) * 8;
         binaryString[i] = userInput.substring(startIndex, endIndex);
      }
      return binaryString;  
   }
}