/**
 * A class for a bubble sorting algorithm
 * @author David Lybeck, Oliver Bacon, Quinn Stober
 * @version 1.0
 */

import java.util.Arrays;
import java.util.Scanner;
public class BubbleSorter extends Sorter{
    public static void main(String[] args){
        Integer size = null;
        boolean run = true;
        while(run) {
            try {
                size = Integer.parseInt(getInput());
                run = false;
            } catch (NumberFormatException Ex) {

            }
        }



        Sorter mySorter = new BubbleSorter();

        int time = mySorter.timeSort(size);
        System.out.println("The array of size " + size + " took " + time + " ms to sort.");
    }

    private static String getInput(){
        Scanner scan = new Scanner(System.in);
        System.out.print("Please enter the array size:");
        String userInput = scan.nextLine();
        return userInput;
    }


    /**
     * Sorts the array using bubble sort
     *
     * @param array  the array to sort
     * @param <E>
     */
    @Override
    public <E extends Comparable<E>> void sort(E[] array){
            int size = array.length;
        //System.out.println(Arrays.toString(array));
            for(int i = 0; i < size - 1; i++){
                for(int j = 0; j < size-i-1; j++){
                    if(array[j].compareTo(array[j + 1]) > 0){
                        //System.out.println("Swapping " + array[j]  + " and " + array[j + 1] + " at index " + j);
                        E temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }
        //System.out.println(Arrays.toString(array));


    }



}
