/**
 * A class for a quick sorting algorithm
 * @author David Lybeck
 * @version 1.0
 */

import java.util.Scanner;
import java.util.Arrays;

public class QuickSorter extends Sorter {
    public static void main(String[] args) {
        int size = -1;
        while (size <= 0) {
            try {
                size = Integer.parseInt(getInput());
            } catch (NumberFormatException Ex) {
                System.out.println("Invalid int");
            }
        }

        Sorter mySorter = new QuickSorter();


        int time = mySorter.timeSort(size);
        System.out.println("The array of size " + size + " took " + time + " ms to sort.");
    }


    private static String getInput() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Please enter the array size:");
        String userInput = scan.nextLine();
        return userInput;
    }


    /**
     * Sorts the array using quick sort
     *
     * @param array the array to sort
     * @param <E>
     */
    @Override
    public <E extends Comparable<E>> void sort(E[] array) {
        sort(array, 0, (array.length - 1));
    }

    private <E extends Comparable<E>> void sort(E[] array, int leftSide, int rightSide) {
        //only run if there is still an area to sort
        if(leftSide<rightSide) {
            //find the pivot Index:

            //set pivot value
            E pivot = array[leftSide];

            int rightCheck = rightSide + 1;
            for(int scanIndex = rightSide; scanIndex > leftSide; scanIndex--){
                //if the number being checked is less than the pivot move to the beginning
                if(array[scanIndex].compareTo(pivot) >= 0){
                    rightCheck--;
                    E temp = array[rightCheck];
                    array[rightCheck] = array[scanIndex];
                    array[scanIndex] = temp;
                }
            }

            //set where the pivot index is
            int pivotIndex = rightCheck - 1;

            //swap the pivot to the correct spot in the array
            E temp = array[pivotIndex];
            array[pivotIndex] = array[leftSide];
            array[leftSide] = temp;


            //sort on the left of the pivot
            sort(array, leftSide, pivotIndex - 1);
            //sort on the right of the pivot
            sort(array, pivotIndex + 1, rightSide);
        }
    }
}